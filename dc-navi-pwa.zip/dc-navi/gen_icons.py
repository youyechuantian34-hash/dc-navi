#!/usr/bin/env python3
"""DC資産ナビ PWAアイコン生成"""
import struct, zlib, base64, os

def make_png(size, bg=(15,23,42), accent=(37,99,235)):
    """シンプルなPNGアイコンを生成"""
    w, h = size, size
    img = []
    for y in range(h):
        row = b'\x00'
        for x in range(w):
            cx, cy = x - w//2, y - h//2
            r = (cx**2 + cy**2) ** 0.5
            margin = w * 0.08

            # 角丸背景
            corner_r = w * 0.22
            in_bg = (x >= margin and x <= w-margin and
                     y >= margin and y <= h-margin)
            in_corner = False
            for (cx2, cy2) in [(margin+corner_r, margin+corner_r),
                               (w-margin-corner_r, margin+corner_r),
                               (margin+corner_r, h-margin-corner_r),
                               (w-margin-corner_r, h-margin-corner_r)]:
                if ((x-cx2)**2 + (y-cy2)**2) < corner_r**2:
                    in_corner = True
            near_corner = (x < margin+corner_r or x > w-margin-corner_r) and \
                          (y < margin+corner_r or y > h-margin-corner_r)
            in_rounded = (in_bg and (not near_corner or in_corner))

            if in_rounded:
                # グラデーション背景
                t = y / h
                r2 = int(15 + (30-15)*t)
                g2 = int(23 + (58-23)*t)
                b2 = int(42 + (92-42)*t)

                # チャート上昇ラインを描画
                line_pts = [
                    (0.15, 0.72), (0.30, 0.65), (0.45, 0.55),
                    (0.60, 0.42), (0.75, 0.32), (0.88, 0.22)
                ]
                fx, fy = x/w, y/h
                on_line = False
                lw = max(2, w//48)
                for i in range(len(line_pts)-1):
                    x1,y1 = line_pts[i]; x2,y2 = line_pts[i+1]
                    if x1 <= fx <= x2:
                        t2 = (fx-x1)/(x2-x1)
                        ey = y1 + (y2-y1)*t2
                        if abs(fy - ey) < lw/h:
                            on_line = True

                # 矢印（右上）
                ax, ay = 0.78, 0.18
                in_arrow = (abs(fx - ax) < 0.08 and abs(fy - ay) < 0.06)

                if on_line or in_arrow:
                    row += bytes([min(255,accent[0]+40), min(255,accent[1]+40), min(255,accent[2]+40), 255])
                else:
                    row += bytes([r2, g2, b2, 255])
            else:
                row += bytes([0, 0, 0, 0])
        img.append(row)

    def chunk(name, data):
        c = zlib.crc32(name + data) & 0xffffffff
        return struct.pack('>I', len(data)) + name + data + struct.pack('>I', c)

    raw = b''.join(img)
    compressed = zlib.compress(raw, 9)
    png = (b'\x89PNG\r\n\x1a\n'
           + chunk(b'IHDR', struct.pack('>IIBBBBB', w, h, 8, 6, 0, 0, 0))
           + chunk(b'IDAT', compressed)
           + chunk(b'IEND', b''))
    return png

os.makedirs("public/icons", exist_ok=True)
for size in [192, 512]:
    with open(f"public/icons/icon-{size}.png", "wb") as f:
        f.write(make_png(size))
    print(f"✅ icon-{size}.png 生成完了")
