# DC資産ナビ 📈

企業型DC（確定拠出年金）の資産をスマホで毎日かんたんに確認・記録できるPWAアプリです。

## 機能
- 📷 JIS&Tのスクリーンショットを撮るだけでAIが自動読み取り
- 📊 資産推移グラフ・商品別内訳
- 🔮 将来シミュレーション（利回り別）
- 💾 データはスマホに自動保存（localStorage）
- 📱 ホーム画面に追加してネイティブアプリのように使える

---

## デプロイ手順（Vercel）

### 1. GitHubにプッシュ
```bash
cd dc-navi
git init
git add .
git commit -m "initial commit"
git branch -M main
git remote add origin https://github.com/あなたのID/dc-navi.git
git push -u origin main
```

### 2. Vercelにデプロイ
1. https://vercel.com にアクセス（GitHubアカウントでログイン）
2. 「New Project」→ リポジトリを選択
3. Framework Preset: **Create React App**
4. 「Deploy」ボタンを押すだけ（約2分）

### 3. iPhoneのホーム画面に追加
1. SafariでVercelのURL（例: `https://dc-navi.vercel.app`）を開く
2. 下部の共有ボタン（□↑）をタップ
3. 「ホーム画面に追加」→「追加」
4. ✅ アイコンがホーム画面に現れてアプリとして起動できます！

---

## ローカルで試す
```bash
npm install
npm start
# → http://localhost:3000 で起動
```

## 注意事項
- 本アプリは情報提供を目的としており、特定の金融商品を推薦するものではありません
- データはデバイスのlocalStorageに保存されます（サーバーには送信されません）
- AI読み取りはAnthropicのAPIを使用します
