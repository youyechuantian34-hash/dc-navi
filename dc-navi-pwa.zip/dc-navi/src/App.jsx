import { useState, useRef, useCallback } from "react";
import { PieChart, Pie, Cell, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, AreaChart, Area } from "recharts";

// ─── 初期データ（画像から読み取った値） ───────────────────────────
const INITIAL_HISTORY = [
  {
    date: "2026-06-21",
    totalValue: 2139243,
    invested: 1062311,
    gain: 1076932,
    products: [
      { id: "030", name: "野村新興国株式インデックスF", ratio: 42, value: 902077, cost: 485094, gain: 416983, gainRate: 85.9 },
      { id: "056", name: "OneDCS&P500IDX", ratio: 30, value: 637415, cost: 646773, gain: -9358, gainRate: -1.5 },
      { id: "034", name: "野村日経225インデF野村DC", ratio: 28, value: 594684, cost: 292946, gain: 301738, gainRate: 103.0 },
    ]
  }
];

const PRODUCT_COLORS = ["#2563EB", "#10B981", "#F59E0B", "#EF4444", "#8B5CF6"];

const fmt = (n) => n?.toLocaleString("ja-JP") ?? "—";
const fmtPct = (n) => (n >= 0 ? `+${n.toFixed(1)}` : n.toFixed(1)) + "%";
const fmtDiff = (n) => (n >= 0 ? `+${fmt(n)}` : `▲${fmt(Math.abs(n))}`);

// ─── Tab icons ────────────────────────────────────────────────────
const IconHome = () => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} className="w-5 h-5">
    <path d="M3 9.5L12 3l9 6.5V20a1 1 0 01-1 1H4a1 1 0 01-1-1V9.5z"/>
    <path d="M9 21V12h6v9"/>
  </svg>
);
const IconPie = () => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} className="w-5 h-5">
    <path d="M21.21 15.89A10 10 0 118 2.83"/>
    <path d="M22 12A10 10 0 0012 2v10z"/>
  </svg>
);
const IconChart = () => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} className="w-5 h-5">
    <polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/>
  </svg>
);
const IconSim = () => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} className="w-5 h-5">
    <circle cx="12" cy="12" r="10"/>
    <polyline points="12 6 12 12 16 14"/>
  </svg>
);
const IconSettings = () => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} className="w-5 h-5">
    <circle cx="12" cy="12" r="3"/>
    <path d="M19.4 15a1.65 1.65 0 00.33 1.82l.06.06a2 2 0 010 2.83 2 2 0 01-2.83 0l-.06-.06a1.65 1.65 0 00-1.82-.33 1.65 1.65 0 00-1 1.51V21a2 2 0 01-4 0v-.09A1.65 1.65 0 009 19.4a1.65 1.65 0 00-1.82.33l-.06.06a2 2 0 01-2.83-2.83l.06-.06A1.65 1.65 0 004.68 15a1.65 1.65 0 00-1.51-1H3a2 2 0 010-4h.09A1.65 1.65 0 004.6 9a1.65 1.65 0 00-.33-1.82l-.06-.06a2 2 0 012.83-2.83l.06.06A1.65 1.65 0 009 4.68a1.65 1.65 0 001-1.51V3a2 2 0 014 0v.09a1.65 1.65 0 001 1.51 1.65 1.65 0 001.82-.33l.06-.06a2 2 0 012.83 2.83l-.06.06A1.65 1.65 0 0019.4 9a1.65 1.65 0 001.51 1H21a2 2 0 010 4h-.09a1.65 1.65 0 00-1.51 1z"/>
  </svg>
);

// ─── AI読み取りモーダル ────────────────────────────────────────────
function UploadModal({ onClose, onSave }) {
  const [image, setImage] = useState(null);
  const [imageB64, setImageB64] = useState(null);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState(null);
  const [error, setError] = useState(null);
  const fileRef = useRef();

  const handleFile = (file) => {
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (e) => {
      setImage(e.target.result);
      setImageB64(e.target.result.split(",")[1]);
    };
    reader.readAsDataURL(file);
  };

  const handleDrop = (e) => {
    e.preventDefault();
    handleFile(e.dataTransfer.files[0]);
  };

  const analyze = async () => {
    if (!imageB64) return;
    setLoading(true);
    setError(null);
    try {
      const prompt = `この画像はJIS&Tの企業型DC（確定拠出年金）の画面です。以下の情報を読み取りJSONのみで返してください。preambleや\`\`\`は不要です。

{
  "totalValue": 年金資産評価額（数値）,
  "invested": 運用金額（数値）,
  "gain": 評価損益（数値）,
  "products": [
    {
      "id": "商品番号",
      "name": "商品名（短縮OK）",
      "ratio": 時価構成比（数値%）,
      "value": 時価評価額（数値）,
      "cost": 取得金額（数値）,
      "gain": 評価損益（数値・損失はマイナス）,
      "gainRate": 評価損益率（数値・損失はマイナス）
    }
  ]
}

商品が複数ページにまたがる場合は見えている分だけでOK。▲はマイナスを意味します。`;

      const res = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          model: "claude-sonnet-4-6",
          max_tokens: 1000,
          messages: [{
            role: "user",
            content: [
              { type: "image", source: { type: "base64", media_type: "image/jpeg", data: imageB64 } },
              { type: "text", text: prompt }
            ]
          }]
        })
      });
      const data = await res.json();
      const text = data.content?.map(b => b.text || "").join("") || "";
      const clean = text.replace(/```json|```/g, "").trim();
      const parsed = JSON.parse(clean);
      setResult(parsed);
    } catch (e) {
      setError("読み取りに失敗しました。別の画像をお試しください。");
    }
    setLoading(false);
  };

  const save = () => {
    if (!result) return;
    const today = new Date().toISOString().split("T")[0];
    onSave({ date: today, ...result });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center" style={{ background: "rgba(0,0,0,0.6)" }}>
      <div className="w-full max-w-md rounded-t-3xl p-6 pb-10" style={{ background: "#0F172A", border: "1px solid #1E3A5F" }}>
        <div className="flex items-center justify-between mb-5">
          <h2 className="text-lg font-bold text-white">画像から資産を読み取る</h2>
          <button onClick={onClose} className="text-gray-400 hover:text-white text-2xl leading-none">×</button>
        </div>

        {!image ? (
          <div
            onDrop={handleDrop}
            onDragOver={e => e.preventDefault()}
            onClick={() => fileRef.current.click()}
            className="border-2 border-dashed rounded-2xl p-10 text-center cursor-pointer"
            style={{ borderColor: "#2563EB" }}
          >
            <div className="text-4xl mb-3">📷</div>
            <p className="text-white font-medium mb-1">スクリーンショットをアップロード</p>
            <p className="text-xs" style={{ color: "#64748B" }}>JIS&Tの評価損益照会・商品別評価損益の画面</p>
            <input ref={fileRef} type="file" accept="image/*" className="hidden" onChange={e => handleFile(e.target.files[0])} />
          </div>
        ) : (
          <div className="space-y-4">
            <img src={image} alt="preview" className="w-full rounded-xl object-contain max-h-48" />
            {!result && (
              <button
                onClick={analyze}
                disabled={loading}
                className="w-full py-3 rounded-xl font-bold text-white transition-all"
                style={{ background: loading ? "#1E3A5F" : "#2563EB" }}
              >
                {loading ? "🔍 AIが読み取り中..." : "✨ AIで読み取る"}
              </button>
            )}
            {error && <p className="text-red-400 text-sm text-center">{error}</p>}
            {result && (
              <div className="rounded-xl p-4 space-y-2" style={{ background: "#1E293B" }}>
                <p className="text-xs font-semibold mb-2" style={{ color: "#60A5FA" }}>読み取り結果</p>
                <div className="flex justify-between text-sm">
                  <span style={{ color: "#94A3B8" }}>年金資産評価額</span>
                  <span className="text-white font-bold">{fmt(result.totalValue)}円</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span style={{ color: "#94A3B8" }}>評価損益</span>
                  <span className="font-bold" style={{ color: result.gain >= 0 ? "#10B981" : "#EF4444" }}>
                    {fmtDiff(result.gain)}円
                  </span>
                </div>
                <div className="mt-2 pt-2" style={{ borderTop: "1px solid #334155" }}>
                  {result.products?.map((p, i) => (
                    <div key={i} className="flex justify-between text-xs py-1">
                      <span style={{ color: "#94A3B8" }}>{p.name}</span>
                      <span style={{ color: p.gain >= 0 ? "#10B981" : "#EF4444" }}>{fmtDiff(p.gain)}円</span>
                    </div>
                  ))}
                </div>
                <button onClick={save} className="w-full py-3 rounded-xl font-bold text-white mt-2" style={{ background: "#10B981" }}>
                  ✅ 保存する
                </button>
              </div>
            )}
            {!result && (
              <button onClick={() => { setImage(null); setImageB64(null); }} className="w-full py-2 text-sm" style={{ color: "#64748B" }}>
                画像を選び直す
              </button>
            )}
          </div>
        )}
      </div>
    </div>
  );
}

// ─── ホーム画面 ───────────────────────────────────────────────────
function HomeTab({ history, settings }) {
  const latest = history[history.length - 1];
  const prev = history[history.length - 2];
  const dayDiff = prev ? latest.totalValue - prev.totalValue : null;
  const gainRate = latest ? ((latest.gain / latest.invested) * 100).toFixed(1) : 0;
  const targetProgress = settings.targetAmount ? Math.min(100, (latest.totalValue / settings.targetAmount) * 100) : null;

  const chartData = history.slice(-12).map(h => ({
    date: h.date.slice(5),
    value: Math.round(h.totalValue / 10000),
  }));

  return (
    <div className="space-y-4 pb-4">
      {/* メインカード */}
      <div className="rounded-2xl p-5 mx-1" style={{ background: "linear-gradient(135deg, #1E3A5F 0%, #0F172A 100%)", border: "1px solid #2563EB33" }}>
        <p className="text-xs mb-1" style={{ color: "#60A5FA" }}>{latest?.date} 時点</p>
        <p className="text-4xl font-black text-white tracking-tight">{fmt(latest?.totalValue)}<span className="text-lg font-normal ml-1">円</span></p>
        {dayDiff !== null && (
          <div className="flex items-center gap-2 mt-1">
            <span className="text-sm font-bold" style={{ color: dayDiff >= 0 ? "#10B981" : "#EF4444" }}>
              前日比 {fmtDiff(dayDiff)}円
            </span>
            <span className="text-xs" style={{ color: dayDiff >= 0 ? "#10B981" : "#EF4444" }}>
              ({dayDiff >= 0 ? "+" : ""}{prev ? ((dayDiff / prev.totalValue) * 100).toFixed(2) : 0}%)
            </span>
          </div>
        )}
        <div className="grid grid-cols-3 gap-3 mt-4">
          {[
            { label: "積立元本", value: fmt(latest?.invested) + "円" },
            { label: "運用益", value: fmtDiff(latest?.gain) + "円", color: latest?.gain >= 0 ? "#10B981" : "#EF4444" },
            { label: "評価損益率", value: fmtPct(Number(gainRate)), color: Number(gainRate) >= 0 ? "#10B981" : "#EF4444" },
          ].map(({ label, value, color }) => (
            <div key={label} className="rounded-xl p-3 text-center" style={{ background: "#0F172A88" }}>
              <p className="text-xs mb-1" style={{ color: "#64748B" }}>{label}</p>
              <p className="text-sm font-bold" style={{ color: color || "white" }}>{value}</p>
            </div>
          ))}
        </div>
      </div>

      {/* 目標進捗 */}
      {targetProgress !== null && (
        <div className="rounded-2xl p-4 mx-1" style={{ background: "#1E293B" }}>
          <div className="flex justify-between items-center mb-2">
            <span className="text-sm font-semibold" style={{ color: "#94A3B8" }}>目標額まで</span>
            <span className="text-xs font-bold" style={{ color: "#60A5FA" }}>
              あと {fmt(settings.targetAmount - latest.totalValue)}円
            </span>
          </div>
          <div className="h-3 rounded-full overflow-hidden" style={{ background: "#0F172A" }}>
            <div className="h-full rounded-full transition-all duration-700" style={{ width: `${targetProgress}%`, background: "linear-gradient(90deg, #2563EB, #10B981)" }} />
          </div>
          <div className="flex justify-between mt-1">
            <span className="text-xs" style={{ color: "#475569" }}>0円</span>
            <span className="text-xs font-bold" style={{ color: "#10B981" }}>{targetProgress.toFixed(1)}%</span>
            <span className="text-xs" style={{ color: "#475569" }}>{fmt(settings.targetAmount)}円</span>
          </div>
        </div>
      )}

      {/* ミニグラフ */}
      {chartData.length > 1 && (
        <div className="rounded-2xl p-4 mx-1" style={{ background: "#1E293B" }}>
          <p className="text-sm font-semibold mb-3" style={{ color: "#94A3B8" }}>資産推移（万円）</p>
          <ResponsiveContainer width="100%" height={120}>
            <AreaChart data={chartData}>
              <defs>
                <linearGradient id="grad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#2563EB" stopOpacity={0.4} />
                  <stop offset="100%" stopColor="#2563EB" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid stroke="#1E3A5F" strokeDasharray="3 3" />
              <XAxis dataKey="date" tick={{ fontSize: 10, fill: "#475569" }} />
              <YAxis tick={{ fontSize: 10, fill: "#475569" }} />
              <Tooltip
                contentStyle={{ background: "#0F172A", border: "1px solid #2563EB", borderRadius: 8, fontSize: 12 }}
                labelStyle={{ color: "#94A3B8" }}
                formatter={(v) => [`${v}万円`, "評価額"]}
              />
              <Area type="monotone" dataKey="value" stroke="#2563EB" strokeWidth={2} fill="url(#grad)" dot={{ fill: "#2563EB", r: 3 }} />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      )}
    </div>
  );
}

// ─── 内訳画面 ─────────────────────────────────────────────────────
function BreakdownTab({ history }) {
  const latest = history[history.length - 1];
  if (!latest) return <div className="text-center text-gray-500 mt-20">データがありません</div>;

  const pieData = latest.products.map(p => ({ name: p.name, value: p.ratio }));

  return (
    <div className="space-y-4 pb-4">
      <div className="rounded-2xl p-5 mx-1" style={{ background: "#1E293B" }}>
        <p className="text-xs mb-3 text-center" style={{ color: "#60A5FA" }}>評価額合計 {fmt(latest.totalValue)}円</p>
        <ResponsiveContainer width="100%" height={200}>
          <PieChart>
            <Pie data={pieData} cx="50%" cy="50%" innerRadius={55} outerRadius={85} paddingAngle={3} dataKey="value">
              {pieData.map((_, i) => <Cell key={i} fill={PRODUCT_COLORS[i % PRODUCT_COLORS.length]} />)}
            </Pie>
            <Tooltip formatter={(v) => [`${v}%`, "構成比"]} contentStyle={{ background: "#0F172A", border: "1px solid #2563EB33", borderRadius: 8, fontSize: 12 }} />
          </PieChart>
        </ResponsiveContainer>
      </div>

      {latest.products.map((p, i) => (
        <div key={p.id} className="rounded-2xl p-4 mx-1" style={{ background: "#1E293B", borderLeft: `3px solid ${PRODUCT_COLORS[i % PRODUCT_COLORS.length]}` }}>
          <div className="flex justify-between items-start mb-3">
            <div className="flex-1">
              <p className="text-xs mb-0.5" style={{ color: "#475569" }}>商品番号 {p.id}</p>
              <p className="text-sm font-bold text-white leading-tight">{p.name}</p>
            </div>
            <span className="text-xs px-2 py-1 rounded-full ml-2" style={{ background: PRODUCT_COLORS[i % PRODUCT_COLORS.length] + "33", color: PRODUCT_COLORS[i % PRODUCT_COLORS.length] }}>
              {p.ratio}%
            </span>
          </div>
          <div className="grid grid-cols-3 gap-2">
            {[
              { label: "時価評価額", value: fmt(p.value) + "円" },
              { label: "取得金額", value: fmt(p.cost) + "円" },
              { label: "評価損益", value: fmtDiff(p.gain) + "円 (" + fmtPct(p.gainRate) + ")", color: p.gain >= 0 ? "#10B981" : "#EF4444" },
            ].map(({ label, value, color }) => (
              <div key={label} className="rounded-xl p-2" style={{ background: "#0F172A88" }}>
                <p className="text-xs mb-1" style={{ color: "#64748B" }}>{label}</p>
                <p className="text-xs font-bold" style={{ color: color || "white" }}>{value}</p>
              </div>
            ))}
          </div>
        </div>
      ))}
    </div>
  );
}

// ─── グラフ画面 ───────────────────────────────────────────────────
function GraphTab({ history }) {
  const [range, setRange] = useState("all");

  const filtered = (() => {
    const now = new Date();
    const cutoff = { "1m": 30, "3m": 90, "6m": 180, "1y": 365 };
    if (range === "all" || !cutoff[range]) return history;
    const limit = new Date(now - cutoff[range] * 86400000);
    return history.filter(h => new Date(h.date) >= limit);
  })();

  const chartData = filtered.map(h => ({
    date: h.date.slice(5),
    value: Math.round(h.totalValue / 10000),
    gain: Math.round(h.gain / 10000),
  }));

  const ranges = ["1m", "3m", "6m", "1y", "all"];

  return (
    <div className="space-y-4 pb-4">
      <div className="flex gap-2 mx-1 overflow-x-auto pb-1">
        {ranges.map(r => (
          <button key={r} onClick={() => setRange(r)}
            className="px-3 py-1 rounded-full text-xs font-bold whitespace-nowrap transition-all"
            style={{ background: range === r ? "#2563EB" : "#1E293B", color: range === r ? "white" : "#64748B" }}>
            {r === "all" ? "全期間" : r}
          </button>
        ))}
      </div>

      <div className="rounded-2xl p-4 mx-1" style={{ background: "#1E293B" }}>
        <p className="text-sm font-semibold mb-3" style={{ color: "#94A3B8" }}>評価額推移（万円）</p>
        <ResponsiveContainer width="100%" height={180}>
          <AreaChart data={chartData}>
            <defs>
              <linearGradient id="g2" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#2563EB" stopOpacity={0.3} />
                <stop offset="100%" stopColor="#2563EB" stopOpacity={0} />
              </linearGradient>
            </defs>
            <CartesianGrid stroke="#1E3A5F" strokeDasharray="3 3" />
            <XAxis dataKey="date" tick={{ fontSize: 10, fill: "#475569" }} />
            <YAxis tick={{ fontSize: 10, fill: "#475569" }} />
            <Tooltip contentStyle={{ background: "#0F172A", border: "1px solid #2563EB33", borderRadius: 8, fontSize: 12 }} formatter={v => [`${v}万円`]} />
            <Area type="monotone" dataKey="value" stroke="#2563EB" strokeWidth={2} fill="url(#g2)" />
          </AreaChart>
        </ResponsiveContainer>
      </div>

      <div className="rounded-2xl p-4 mx-1" style={{ background: "#1E293B" }}>
        <p className="text-sm font-semibold mb-3" style={{ color: "#94A3B8" }}>評価損益推移（万円）</p>
        <ResponsiveContainer width="100%" height={150}>
          <LineChart data={chartData}>
            <CartesianGrid stroke="#1E3A5F" strokeDasharray="3 3" />
            <XAxis dataKey="date" tick={{ fontSize: 10, fill: "#475569" }} />
            <YAxis tick={{ fontSize: 10, fill: "#475569" }} />
            <Tooltip contentStyle={{ background: "#0F172A", border: "1px solid #10B98133", borderRadius: 8, fontSize: 12 }} formatter={v => [`${v}万円`]} />
            <Line type="monotone" dataKey="gain" stroke="#10B981" strokeWidth={2} dot={{ fill: "#10B981", r: 3 }} />
          </LineChart>
        </ResponsiveContainer>
      </div>

      {/* 期間別サマリー */}
      {history.length >= 2 && (
        <div className="rounded-2xl p-4 mx-1" style={{ background: "#1E293B" }}>
          <p className="text-sm font-semibold mb-3" style={{ color: "#94A3B8" }}>期間別損益</p>
          {[
            { label: "前回比", idx: -2 },
          ].map(({ label, idx }) => {
            const ref = history[history.length + idx];
            if (!ref) return null;
            const diff = history[history.length - 1].totalValue - ref.totalValue;
            return (
              <div key={label} className="flex justify-between py-2" style={{ borderBottom: "1px solid #1E3A5F" }}>
                <span className="text-sm" style={{ color: "#94A3B8" }}>{label} ({ref.date})</span>
                <span className="text-sm font-bold" style={{ color: diff >= 0 ? "#10B981" : "#EF4444" }}>{fmtDiff(diff)}円</span>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

// ─── シミュレーション ─────────────────────────────────────────────
function SimTab({ history, settings, setSettings }) {
  const latest = history[history.length - 1];
  const currentAge = Number(settings.currentAge) || 40;
  const targetAge = Number(settings.targetAge) || 65;
  const monthly = Number(settings.monthly) || 10000;
  const rate = Number(settings.rate) || 5;
  const yearsLeft = targetAge - currentAge;
  const currentValue = latest?.totalValue || 0;

  const simulate = (r) => {
    const monthlyRate = r / 100 / 12;
    const months = yearsLeft * 12;
    const future = currentValue * Math.pow(1 + monthlyRate, months)
      + monthly * ((Math.pow(1 + monthlyRate, months) - 1) / monthlyRate);
    return Math.round(future);
  };

  const chartSim = Array.from({ length: yearsLeft + 1 }, (_, y) => {
    const m = y * 12;
    const mr = rate / 100 / 12;
    const v = currentValue * Math.pow(1 + mr, m) + monthly * ((Math.pow(1 + mr, m) - 1) / mr);
    return { age: currentAge + y, value: Math.round(v / 10000) };
  });

  return (
    <div className="space-y-4 pb-4">
      <div className="rounded-2xl p-4 mx-1 space-y-3" style={{ background: "#1E293B" }}>
        <p className="text-sm font-semibold" style={{ color: "#60A5FA" }}>シミュレーション条件</p>
        {[
          { label: "現在の年齢", key: "currentAge", unit: "歳" },
          { label: "目標年齢", key: "targetAge", unit: "歳" },
          { label: "毎月の掛金", key: "monthly", unit: "円" },
          { label: "目標金額", key: "targetAmount", unit: "円" },
        ].map(({ label, key, unit }) => (
          <div key={key} className="flex items-center justify-between">
            <span className="text-sm" style={{ color: "#94A3B8" }}>{label}</span>
            <div className="flex items-center gap-1">
              <input
                type="number"
                value={settings[key] || ""}
                onChange={e => setSettings(s => ({ ...s, [key]: e.target.value }))}
                className="w-24 px-2 py-1 rounded-lg text-sm text-right text-white outline-none"
                style={{ background: "#0F172A", border: "1px solid #2563EB44" }}
              />
              <span className="text-xs" style={{ color: "#64748B" }}>{unit}</span>
            </div>
          </div>
        ))}
        <div className="flex items-center justify-between">
          <span className="text-sm" style={{ color: "#94A3B8" }}>想定利回り</span>
          <div className="flex gap-1">
            {[3, 5, 7, 10].map(r => (
              <button key={r} onClick={() => setSettings(s => ({ ...s, rate: r }))}
                className="px-2 py-1 rounded-lg text-xs font-bold transition-all"
                style={{ background: Number(settings.rate) === r ? "#2563EB" : "#0F172A", color: Number(settings.rate) === r ? "white" : "#64748B" }}>
                {r}%
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* 予測グラフ */}
      <div className="rounded-2xl p-4 mx-1" style={{ background: "#1E293B" }}>
        <p className="text-sm font-semibold mb-1" style={{ color: "#94A3B8" }}>将来予測（万円）</p>
        <p className="text-3xl font-black text-white mb-3">{fmt(Math.round(simulate(rate) / 10000))}<span className="text-sm font-normal ml-1">万円</span></p>
        <ResponsiveContainer width="100%" height={160}>
          <AreaChart data={chartSim}>
            <defs>
              <linearGradient id="simGrad" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#F59E0B" stopOpacity={0.4} />
                <stop offset="100%" stopColor="#F59E0B" stopOpacity={0} />
              </linearGradient>
            </defs>
            <CartesianGrid stroke="#1E3A5F" strokeDasharray="3 3" />
            <XAxis dataKey="age" tick={{ fontSize: 10, fill: "#475569" }} tickFormatter={v => `${v}歳`} />
            <YAxis tick={{ fontSize: 10, fill: "#475569" }} />
            <Tooltip contentStyle={{ background: "#0F172A", border: "1px solid #F59E0B33", borderRadius: 8, fontSize: 12 }} formatter={v => [`${fmt(v)}万円`]} labelFormatter={l => `${l}歳`} />
            {settings.targetAmount && (
              <Line type="monotone" dataKey={() => Math.round(settings.targetAmount / 10000)} stroke="#EF4444" strokeDasharray="4 4" strokeWidth={1} dot={false} />
            )}
            <Area type="monotone" dataKey="value" stroke="#F59E0B" strokeWidth={2} fill="url(#simGrad)" />
          </AreaChart>
        </ResponsiveContainer>
      </div>

      {/* 利回り別比較 */}
      <div className="rounded-2xl p-4 mx-1" style={{ background: "#1E293B" }}>
        <p className="text-sm font-semibold mb-3" style={{ color: "#94A3B8" }}>利回り別 {targetAge}歳時点の予測</p>
        {[3, 5, 7, 10].map(r => (
          <div key={r} className="flex justify-between py-2" style={{ borderBottom: "1px solid #1E3A5F" }}>
            <span className="text-sm" style={{ color: "#94A3B8" }}>{r}%</span>
            <span className="text-sm font-bold text-white">約 {fmt(Math.round(simulate(r) / 10000))}万円</span>
          </div>
        ))}
      </div>
    </div>
  );
}

// ─── 設定画面 ─────────────────────────────────────────────────────
function SettingsTab({ history, setHistory }) {
  return (
    <div className="space-y-4 pb-4 mx-1">
      <div className="rounded-2xl p-4" style={{ background: "#1E293B" }}>
        <p className="text-sm font-semibold mb-3" style={{ color: "#60A5FA" }}>記録履歴</p>
        {history.length === 0 ? (
          <p className="text-sm text-center py-4" style={{ color: "#475569" }}>まだ記録がありません</p>
        ) : (
          <div className="space-y-2">
            {[...history].reverse().map((h, i) => (
              <div key={h.date + i} className="flex items-center justify-between p-3 rounded-xl" style={{ background: "#0F172A" }}>
                <div>
                  <p className="text-sm font-bold text-white">{h.date}</p>
                  <p className="text-xs" style={{ color: "#64748B" }}>{fmt(h.totalValue)}円</p>
                </div>
                <button
                  onClick={() => setHistory(prev => prev.filter((_, idx) => prev.length - 1 - i !== idx))}
                  className="text-xs px-2 py-1 rounded-lg"
                  style={{ background: "#EF444422", color: "#EF4444" }}
                >
                  削除
                </button>
              </div>
            ))}
          </div>
        )}
      </div>
      <div className="rounded-2xl p-4" style={{ background: "#1E293B" }}>
        <p className="text-xs text-center" style={{ color: "#475569" }}>
          ※本アプリは情報提供を目的としており、特定の金融商品を推薦するものではありません。
        </p>
      </div>
    </div>
  );
}

// ─── localStorage hooks ───────────────────────────────────────────
function useLocalStorage(key, defaultValue) {
  const [value, setValue] = useState(() => {
    try {
      const saved = localStorage.getItem(key);
      return saved ? JSON.parse(saved) : defaultValue;
    } catch { return defaultValue; }
  });
  const set = useCallback((updater) => {
    setValue(prev => {
      const next = typeof updater === "function" ? updater(prev) : updater;
      try { localStorage.setItem(key, JSON.stringify(next)); } catch {}
      return next;
    });
  }, [key]);
  return [value, set];
}

// ─── メインアプリ ─────────────────────────────────────────────────
export default function App() {
  const [tab, setTab] = useState("home");
  const [history, setHistory] = useLocalStorage("dc-navi-history", INITIAL_HISTORY);
  const [showUpload, setShowUpload] = useState(false);
  const [settings, setSettings] = useLocalStorage("dc-navi-settings", {
    currentAge: 40, targetAge: 65, monthly: 23000, targetAmount: 20000000, rate: 5
  });

  const handleSave = useCallback((entry) => {
    setHistory(prev => {
      const exists = prev.findIndex(h => h.date === entry.date);
      if (exists >= 0) {
        const next = [...prev];
        next[exists] = entry;
        return next;
      }
      return [...prev, entry].sort((a, b) => a.date.localeCompare(b.date));
    });
  }, []);

  const tabs = [
    { id: "home", label: "ホーム", icon: <IconHome /> },
    { id: "breakdown", label: "内訳", icon: <IconPie /> },
    { id: "graph", label: "グラフ", icon: <IconChart /> },
    { id: "sim", label: "シミュ", icon: <IconSim /> },
    { id: "settings", label: "設定", icon: <IconSettings /> },
  ];

  return (
    <div className="min-h-screen flex flex-col" style={{ background: "#0F172A", fontFamily: "'Hiragino Sans', 'Noto Sans JP', sans-serif", maxWidth: 480, margin: "0 auto" }}>
      {/* ヘッダー */}
      <div className="flex items-center justify-between px-4 pt-12 pb-4" style={{ background: "#0F172A", borderBottom: "1px solid #1E3A5F" }}>
        <div>
          <p className="text-xs" style={{ color: "#60A5FA" }}>DC資産ナビ</p>
          <h1 className="text-lg font-black text-white">
            {tabs.find(t => t.id === tab)?.label === "ホーム" ? "資産サマリー" : tabs.find(t => t.id === tab)?.label === "内訳" ? "商品別内訳" : tabs.find(t => t.id === tab)?.label}
          </h1>
        </div>
        <button
          onClick={() => setShowUpload(true)}
          className="flex items-center gap-2 px-3 py-2 rounded-xl text-sm font-bold text-white transition-all"
          style={{ background: "linear-gradient(135deg, #2563EB, #1D4ED8)" }}
        >
          <span>📷</span> 更新
        </button>
      </div>

      {/* コンテンツ */}
      <div className="flex-1 overflow-y-auto pt-4">
        {tab === "home" && <HomeTab history={history} settings={settings} />}
        {tab === "breakdown" && <BreakdownTab history={history} />}
        {tab === "graph" && <GraphTab history={history} />}
        {tab === "sim" && <SimTab history={history} settings={settings} setSettings={setSettings} />}
        {tab === "settings" && <SettingsTab history={history} setHistory={setHistory} />}
      </div>

      {/* ボトムナビ */}
      <div className="flex" style={{ background: "#0F172A", borderTop: "1px solid #1E3A5F", paddingBottom: "env(safe-area-inset-bottom, 16px)" }}>
        {tabs.map(t => (
          <button key={t.id} onClick={() => setTab(t.id)}
            className="flex-1 flex flex-col items-center gap-1 py-3 transition-all"
            style={{ color: tab === t.id ? "#2563EB" : "#475569" }}>
            {t.icon}
            <span className="text-xs">{t.label}</span>
          </button>
        ))}
      </div>

      {showUpload && <UploadModal onClose={() => setShowUpload(false)} onSave={handleSave} />}
    </div>
  );
}
